# Summary

![Line coverage](https://img.shields.io/badge/lines-69.4%25-C10909) ![Branch coverage](https://img.shields.io/badge/branches-50%25-C10909) ![Method coverage](https://img.shields.io/badge/methods-66.6%25-C10909) ![Full method coverage](https://img.shields.io/badge/methods-50%25-C10909)

|**Assembly**|**Line coverage**|**Branch coverage**|**Method coverage**|**Full method coverage**|
|:---|---:|---:|---:|---:|
|**Sample**|**69.4%**|**50%**|**66.6%**|**50%**|
